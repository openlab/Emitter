<?php defined('BASEPATH') OR exit; ?>
        <div class="content-page">
            <h1>Developer</h1>
            <p>The Emitter API is available for use for free and provides you with search capabilities and retrieval of an individual facility's details. Furthermore, there are two distinct HTTP API requests that can be made to interact with the data used on Emitter.ca.</p>
			<p class="spacer">&nbsp;</p>
			
			<p>The Emitter API will be made available for public use in the near future.</p>
        </div>