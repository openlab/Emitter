<?php defined('BASEPATH') OR exit; ?>
    </div>
    <div class="footer">
		<?php /* <div style="float: right;"><a href="http://www.redbitdev.com/" title="RedBit Development"><img src="<?php print $base_url; ?>assets/images/RedBitDevelopmentLogo.png" width="126px" height="33px" alt="RedBit Development" title="RedBit Development" /></a></div> */ ?>
    
        <p><?php print anchor('/', 'Emitter'); ?> powered by <a href="http://datadotgc.ca/" title="data(dot)gc.ca">data(dot)gc.ca</a>, <a href="http://www.microsoft.com/industry/government/opengovdata/" title="Microsoft OGDI">OGDI on Azure</a> &amp; <a href="http://port25.ca" title="Microsoft Canada Openness Lab">Microsoft Canada Openness Lab</a></p>
    </div>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-18991557-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body>
</html>